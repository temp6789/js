from lxml import etree

xsd_doc = etree.parse("employees.xsd")
xsd_schema = etree.XMLSchema(xsd_doc)

xml_doc = etree.parse("employees.xml")

if xsd_schema.validate(xml_doc):
    print("✅ XML is valid according to the XSD schema.")
else:
    print("❌ XML is invalid!")
    for error in xsd_schema.error_log:
        print(f"Line {error.line}: {error.message}")