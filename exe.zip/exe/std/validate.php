<?php
$xml = new DOMDocument();
$xml->load("student.xml");
if ($xml->validate()) {
    echo "✅ XML is valid according to the DTD.";
} else {
    echo "❌ XML is invalid!";
}
?>