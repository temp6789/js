<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8" />
 <title>Simple Calculator</title>
 <style>
 body { font-family: Arial, sans-serif; margin: 40px; }
 input, select { padding: 8px; margin: 5px 0; font-size: 16px; }
 button { padding: 8px 16px; font-size: 16px; margin-top: 10px; }
 .result { margin-top: 20px; font-weight: bold; }
 </style>
</head>
<body>
<h2>Basic Arithmetic Calculator</h2>
<form method="POST" action="">
 <label>Number 1:</label><br/>
 <input type="number" step="any" name="num1" required /><br/>
 <label>Number 2:</label><br/>
 <input type="number" step="any" name="num2" required /><br/>
 <label>Operation:</label><br/>
 <select name="operation" required>
 <option value="add">Addition (+)</option>
 <option value="subtract">Subtraction (-)</option>
 <option value="multiply">Multiplication (×)</option>
 <option value="divide">Division (÷)</option>
 </select><br/>
 <button type="submit">Calculate</button>
</form>
<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
 $num1 = floatval($_POST['num1']);
 $num2 = floatval($_POST['num2']);
 $operation = $_POST['operation'];
 $result = null;
 $error = null;
 switch ($operation) {
 case 'add': $result = $num1 + $num2; break;
 case 'subtract': $result = $num1 - $num2; break;
 case 'multiply': $result = $num1 * $num2; break;
 case 'divide':
 if ($num2 == 0) { $error = "Error: Division by zero."; }
 else { $result = $num1 / $num2; }
 break;
 default: $error = "Invalid operation."; }
 echo "<div class='result'>";
 if ($error) echo "<span style='color:red;'>$error</span>";
 else echo "Result: <strong>$result</strong>";
 echo "</div>";
}
?>
</body>
</html>