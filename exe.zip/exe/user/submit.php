<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 $name = htmlspecialchars(trim($_POST['name']));
 $email = htmlspecialchars(trim($_POST['email']));
 $age = intval($_POST['age']);
 if (empty($name) || empty($email) || $age <= 0) {
 echo "Invalid input. Please go back and fill out the form correctly.";
 exit;
 }
} else {
 header("Location: form.html");
 exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>User Information Submitted</title>
<style>
body { font-family: Arial; margin: 40px; }
.info { max-width: 400px; padding: 20px; background-color: #eef2f7; border-radius: 8px; }
</style>
</head>
<body>
<h2>User Information Submitted</h2>
<div class="info">
<p><strong>Name:</strong> <?php echo $name; ?></p>
<p><strong>Email:</strong> <?php echo $email; ?></p>
<p><strong>Age:</strong> <?php echo $age; ?></p>
</div>
<a href="form.html">Go back to the form</a>
</body>
</html>